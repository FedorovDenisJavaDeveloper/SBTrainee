import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static String pathCsvCities = "src"
            + File.separator + "main"
            + File.separator + "resources"
            + File.separator + "Задача ВС Java Сбер.csv";

    public static char DELIMITER = ';';

    public static void main(String[] args) {
        List<City> cities = new ArrayList<>();
        CSVParser csvParser = new CSVParserBuilder().withSeparator(DELIMITER).build();
        try (Scanner sc = new Scanner(new File(pathCsvCities))) {
            while (sc.hasNextLine()) {
                String[] res = csvParser.parseLine(sc.nextLine());
                cities.add(new City(res[0], res[1], res[2], res[3], res[4], res[5]));
            }
            cities.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
